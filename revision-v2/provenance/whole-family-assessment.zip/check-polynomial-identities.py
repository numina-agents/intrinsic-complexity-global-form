"""Corvus's independent integer-polynomial check of the displayed identities.

This checks the paper's finite arithmetic, not its external categorical theorems.
Coefficients are stored in increasing powers. No third-party packages.
"""

def trim(a):
    while len(a) > 1 and a[-1] == 0:
        a.pop()
    return a

def add(*args):
    out = [0] * max(map(len, args))
    for a in args:
        for i, v in enumerate(a):
            out[i] += v
    return trim(out)

def scale(n, a):
    return trim([n*v for v in a])

def mul(a, b):
    out = [0] * (len(a)+len(b)-1)
    for i, v in enumerate(a):
        for j, w in enumerate(b):
            out[i+j] += v*w
    return trim(out)

def div_monic(a, b):
    a = a[:]
    q = [0] * max(1, len(a)-len(b)+1)
    while a != [0] and len(a) >= len(b):
        d = len(a)-len(b)
        v = a[-1]
        q[d] = v
        a = add(a, [0]*d + scale(-v,b))
    return trim(q), trim(a)

f=[1,0,-3,1]; x=[0,1]; x2=mul(x,x)
a=[0,-1,1]; b=[-1,-1,1]
c1=[-1,-2,1]; c2=[0,3,-1]; c4=[1,-1]
aa=mul(a,a); ab=mul(a,b); bb=mul(b,b)
ax=mul(a,x); bx=mul(b,x)
numerators=[
    add([1],aa,bb,scale(3,x2)),
    add(scale(-1,a),scale(2,aa),scale(-2,ab),bb,
        scale(3,mul(ax,c1)),scale(3,mul(bx,c4)),scale(6,x2)),
    add(scale(-1,b),scale(2,aa),scale(-1,ab),bb,
        scale(3,mul(ax,c1)),scale(3,mul(bx,c4)),scale(3,x2)),
    add(mul(x,c2),aa,scale(-1,ab),bb,
        scale(2,mul(ax,c1)),mul(bx,c4),scale(3,x2)),
]
expected=[[2,2],[1,-2,3],[2,-1,3],[1,0,2]]
for label, n, e in zip(['1','Y2','Y3','Xi'],numerators,expected):
    quotient,remainder=div_monic(add(n,scale(-9,x2)),f)
    assert quotient==e and remainder==[0]
    print(label, 'quotient coefficients=',quotient,'remainder=',remainder)
print('All four displayed indicator/global-dimension identities pass over Z[x].')
