# P25 family revision: independent reading log

Corvus, outside assessor under director 4968/4982. Whole-assessment cap: 12:00 UTC, 14 November 2026; automatic daily pause overrides. No derivation or repair role.

## Fixed account

- COMPLETE publication source read from title through bibliography, SHA256 `2252e14ed28171f9a0cd2fda0bf1592035b8de061c446eba4c3958e3f08f6e84`.
- COMPLETE `SOURCE-AUDIT.txt` read. Both exact whole-source author approvals: 4974/4978.
- Own clone `supplement/`, initial release 53468e5, packaging release 4de8111. Diff contains only checksum manifests and the archived Polaris approval. Actual `SHA256SUMS` validation: 26 top-level entries and 11 revision entries PASS. Publication bytes unchanged.
- All NINE primary PDFs independently fetched from their exact arXiv versions into `sources/`; every SHA256 agrees with the packet's SOURCES.tsv. No inherited author/component/v1 verdict adopted.
- V1 source read in full for orientation, not as certification of the revision. V1 journal report not yet independently read in full.

## Primary readings completed by 11:17

1. Edie-Michell 2102.09065v4: complete Lemmas 2.15–2.20/context and their proofs; COMPLETE Lemma 3.8 proof and its explicit character-idempotent calculation; complete Lemma 5.3 proof. The three excluded pointed low cases include level 3, not levels 6/9. Parameters r=2, m=m'=3, m''=1 give Inv and universal grading trivial. The Omega stabilizer is bounded by the labelled D3 actions, INCLUDING level 9. A prose/display line after the rotation calculation repeats the reflection action; the lemma statement and the actual idempotent calculation give the correct rotation. Did not reprove the cited Thurston/planar-algebra classification or all later exceptional realizations. Main proof needs only the stabilizer upper bound, not the full group realization.

2. Schopieray 1608.03155v2: COMPLETE Example 3.5.2 fusion-rule/self-duality argument and Theorem 1 proof including Lemma 3.5.3 and its final dimension estimate; also Lemma 3.2.1 twist formula/proof. Family simplicity is stated for every m>=2. The displayed resolved twist eta in Example 3.5.2 conflicts with the source's own parent formula: h(2,2)=8/9 at level 6. The submitted revision explicitly uses parent twist descent eta^{-1}. Earlier fusion-generator lemmas remain credited published dependencies, not independently reproved.

3. BHP reality 2608.23693v1: COMPLETE section 5.1, including Definitions 21/22, Lemma 9, Proposition 4 and proof, Corollary 4, Theorem 1/Takagi construction, Corollary 5 and proof. The exact sufficient criterion is unitary ribbon, all simples self-dual, second indicators a Z2 grading. It constructs actual unitary real fusion bases; it is not merely a permutation condition. Graphical structural-functor lemmas cited from earlier sections are not all independently rechecked yet.

4. Nikshych 1801.06125v2: COMPLETE Corollary 4.8 proof/context. Hypotheses are trivial pointed subcategory and existence of a nondegenerate braiding; all braidings are then the independent reversals of prime factors. Did not independently reprove the entire preceding braiding classification.

5. Braunling 2005.05243v1: exact Theorem 2.4 and COMPLETE normalized abelian-cocycle/coboundary definitions in section 2. Coefficients may be ANY abelian group, hence R^times. Trace one means trivial abelian class over R^times, rather than just over C^times. The classical Eilenberg–Mac Lane theorem is credited prior, not independently reproved.

6. Galindo 2608.23743v1: section 3.2 and its COMPLETE Lemma 3.2/Proposition 3.3 proofs; complete Proposition 3.6/Theorem 3.7 proof; COMPLETE Lemma 3.23 proof. Same quasi-R tensorator supplies coherent bar and reversal. Remaining Lemma 3.4/3.5 frame/descent passage still to finish. Underlying quantum-group/canonical-basis source dependencies are credited prior, not independently reconstructed.

## Additional checks completed by 11:28

- Galindo COMPLETE Lemmas 3.4/3.5 and the frame/descent passage read. No extra simple-frame hypothesis remains unverified at the theorem-use level.
- FRS COMPLETE Proposition 4.7 proof read, including reciprocity, graded product, and the commutator argument through (4.37); the stabilizer context around (4.8)–(4.11) also read. Earlier graphical preliminaries remain published dependencies.
- Ng–Schauenburg COMPLETE Theorem 7.5 proof, section-7 spherical/modular setup and Remark 7.6 read. Denominator is global dimension, sum is over ordered pairs, no anomaly shift belongs in theta.
- Edie-Michell COMPLETE relevant 2.12–2.14 statements/context and Theorem 1.4 statement additionally read. In particular dimensions divide by stabilizer order and twists descend unchanged. Nikshych Theorem 4.1/Remark 4.2 and Corollary 4.8 checked for ALL braidings on the fixed tensor category, not merely two equivalence-class names.
- Schopieray parent quantum Weyl formula read. Complete paper fusion table matches the source. Parent twists h(1,1)=1/3, h(3,3)=5/3, h(2,2)=8/9 at k=6 agree with the revision's convention.
- COMPLETE supplied exact script read and rerun successfully: all six indicators +1, all 36 fusion-dimension identities and self-duality conditions pass. Output saved supplied-check-rerun.txt. It is an arithmetic consistency check, not a new categorical realization.
- Separate standard-library integer-polynomial engine checks ALL four unreduced numerator/global-dimension identities; exact quotients (in ascending coefficients) are [2,2], [1,-2,3], [2,-1,3], [1,0,2], all zero remainder. Code check-polynomial-identities.py and output independent-polynomial-check.txt. These are my independent finite arithmetic checks, not a new family derivation.
- Further exact field cross-check using the supplied cyclotomic engine verifies x=1+q+q^{-1}, all dimensions (1,a,b,x,x,x), Dim=9x^2, the cubic and all three c_r identities. No numerical recognition.
- BHP complex COMPLETE introduction and conclusion read, not all explicit invariant calculations. BHP real section-6.7 global-form setup/footnote 28 and COMPLETE section 8 read. Galindo COMPLETE introduction read for simply connected/zesting scope. These sources do not state the full-center family classification.
- Targeted current web searches for PSU(3), real associators, inherently complex F-symbols and condensation found no covering theorem; this is not an exhaustive novelty certificate. Source claims rely on the independently obtained PRIMARY PDFs, not on third-party search summaries.
- COMPLETE two Polaris boundary provenance notes and revision README/check log inspected, without adopting their component verdicts as my whole assessment. All author/publication source bytes unchanged; pinned clone git status clean.
- Independently compiled the pinned source twice in my own build/ directory: eight pages, final log has no warnings or unresolved references. No author source edits.
- Useful source summaries posted in #literature: 4999–5001 and 5004–5009, with exact hypotheses and reading limits. Direction review answered immediately in 5011.

The whole correctness/prior/significance report is being written. No whole verdict has yet been posted as of this entry.
